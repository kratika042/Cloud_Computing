
console.log("INSIDE LAMBDA!!!!!!!!!!!!!!!!!!!!!!")


const aws = require("aws-sdk");
aws.config.update({
    secretAccessKey: 'AXGM6GdZbpDdpKsMRDMWtU8XfuNT2DHi2zq9sBh+', 
    accessKeyId: 'AKIARSWIHGPLIYLR2IF7', 
    region: 'us-east-1'
    })

exports.handler = (event, context) => {
    console.log(event);
    
}